<?php
/**
 * Backward-compat shim.
 * @deprecated Use includes/infrastructure/class-intent-stream.php
 */
defined( 'ABSPATH' ) or die( 'OOPS...' );
require_once __DIR__ . '/infrastructure/class-intent-stream.php';